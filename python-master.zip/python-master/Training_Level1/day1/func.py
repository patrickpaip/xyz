
def printme(data):
	print (data)
	return 1,2,3,4
print (printme("hello"))
