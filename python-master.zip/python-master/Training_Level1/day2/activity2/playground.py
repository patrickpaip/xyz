string="Hello World OK"
print (string.split())
print (string.partition(' '))